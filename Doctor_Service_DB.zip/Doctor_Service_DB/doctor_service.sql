-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 11:34 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor_service`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(11) NOT NULL,
  `doc_nic` varchar(20) NOT NULL,
  `doc_fname` varchar(45) NOT NULL,
  `doc_lname` varchar(45) NOT NULL,
  `DOB` date NOT NULL,
  `age` int(3) NOT NULL,
  `doc_email` varchar(60) NOT NULL,
  `doc_gender` varchar(10) NOT NULL,
  `liscen_no` varchar(8) NOT NULL,
  `specialization` varchar(50) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `doc_charge` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `doc_nic`, `doc_fname`, `doc_lname`, `DOB`, `age`, `doc_email`, `doc_gender`, `liscen_no`, `specialization`, `phone`, `doc_charge`) VALUES
(1, '928590136V', 'Dr.Suu', 'Samarasinghe', '1988-06-01', 32, 'suu%40gmail.com', 'Female', 'D78543', 'Endocnnologist', '0779843476', 1200),
(2, '806275562X', 'Dr.Sameera', 'Jayakody', '1983-05-03', 37, 'sam%40gmail.com', 'Male', 'D62873', 'Mycologist', '0715627838', 1500),
(3, '806278825V', 'Dr.Sachintha', 'Leeniyagoda', '1980-04-05', 40, 'sach%40gmail.com', 'Male', 'D63894', 'Accupuncture', '0774524563', 1800),
(4, '956256478V', 'Dr.Vinodya', 'De+Silva', '1960-06-06', 60, 'vino%40gmail.com', 'Female', 'D53767', 'Cardiac+Surgeon', '0796276373', 1700),
(6, '703243242V', 'Dr.Nishan', 'Senadira', '1979-03-03', 41, 'nish@gmail.com', 'Male', 'D84394', 'Dentist', '0726463584', 2500),
(8, '793436435V', 'Dr.Dumindu', 'Jayakody', '1976-08-21', 44, 'dumi%40gmail.com', 'Male', 'D32573', 'General', '0782532657', 3200);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
